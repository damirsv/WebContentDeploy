#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_TREE                                101
#define IDD_ABOUTDLG                            103
#define IDC_TREE1                               1002
#define IDC_WEB                                 1002
